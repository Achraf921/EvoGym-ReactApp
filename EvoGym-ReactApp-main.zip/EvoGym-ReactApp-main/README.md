# EvoGym-ReactApp
EvoGym is a modern, responsive front-end project tailored for fitness enthusiasts. With a sleek and interactive UI, EvoGym delivers an engaging experience that adapts seamlessly across devices. Built using React, Tailwind CSS, and TypeScript, this project demonstrates good practices in component-driven development.
